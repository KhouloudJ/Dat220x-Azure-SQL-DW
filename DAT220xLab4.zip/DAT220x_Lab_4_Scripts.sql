/* Exercise 4 */
/* The following CREATE LOGIN statement needs to be executed in the master database. 
Create a new query window, copy, paste, and execute the following statement against the master database. */
CREATE LOGIN ApplicationLogin WITH PASSWORD = 'Awes0me_P@ssw0rd!';


/* The following statements need to be executed in the SQL DW database. 
Execute the following statement against the SQL DW database. */
CREATE USER ApplicationUser FOR LOGIN ApplicationLogin;

CREATE ROLE dw_admin;

GRANT
	ALTER,
	CONTROL,
	DELETE,
	EXECUTE,
	INSERT,
	SELECT,
	UPDATE,
	TAKE OWNERSHIP,
	VIEW DEFINITION
ON SCHEMA::dbo
TO dw_admin;

EXECUTE sp_addrolemember N'dw_admin', N'ApplicationUser';

SELECT * FROM sys.database_principals

EXECUTE sp_addrolemember N'DBMANAGER', N'ApplicationUser';
EXECUTE sp_addrolemember N'LOGINMANAGER', N'ApplicationUser';


/* Exercise 5 */
SELECT	es.[status],
		es.query_count,
		er.[status],
		er.submit_time,
		er.start_time,
		er.end_time,
		er.total_elapsed_time,
		er.[label],
		er.resource_class,
		er.command
FROM sys.dm_pdw_exec_requests er
JOIN sys.dm_pdw_exec_sessions es ON er.session_id = es.session_id


SELECT	w.[type],
		w.[object_type],
		w.[object_name],
		w.[state],
		es.[status],
		es.query_count,
		er.[status],
		er.submit_time,
		er.start_time,
		er.end_time,
		er.total_elapsed_time,
		er.[label],
		er.resource_class,
		er.command
FROM sys.dm_pdw_exec_requests er
JOIN sys.dm_pdw_exec_sessions es ON er.session_id = es.session_id
JOIN sys.dm_pdw_waits w ON es.session_id = w.session_id


SELECT * FROM sys.dm_pdw_wait_stats

/* Additional DMVs */
SELECT * FROM sys.dm_pdw_nodes_resource_governor_workload_groups
SELECT * FROM sys.dm_pdw_nodes_resource_governor_resource_pools
SELECT * FROM sys.dm_pdw_nodes

/*********************************
CLEANUP
*********************************/

/* Exercise 4 */
EXECUTE sp_droprolemember 'dw_admin', 'ApplicationUser'
DROP ROLE dw_admin;
DROP USER ApplicationUser;

--In the master database, execute the following statement:
DROP LOGIN ApplicationLogin;